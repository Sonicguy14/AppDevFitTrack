"use client"

import { useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const Dashboard = () => {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState("overview")

  // Modal states
  const [showAddWorkoutModal, setShowAddWorkoutModal] = useState(false)
  const [showEditWorkoutModal, setShowEditWorkoutModal] = useState(false)
  const [showAddWeightModal, setShowAddWeightModal] = useState(false)
  const [showEditWeightModal, setShowEditWeightModal] = useState(false)
  const [showAddMealModal, setShowAddMealModal] = useState(false)
  const [showEditMealModal, setShowEditMealModal] = useState(false)
  const [showAddGoalModal, setShowAddGoalModal] = useState(false)
  const [showEditGoalModal, setShowEditGoalModal] = useState(false)

  // Form data states
  const [newWorkout, setNewWorkout] = useState({ name: "", duration: "", calories: "", date: "" })
  const [newWeight, setNewWeight] = useState({ weight: "", date: "" })
  const [newMeal, setNewMeal] = useState({ name: "", calories: "", type: "breakfast", date: "" })
  const [newGoal, setNewGoal] = useState({ name: "", target: "", current: "", targetDate: "" })

  // Editing states
  const [editingWorkout, setEditingWorkout] = useState(null)
  const [editingWeight, setEditingWeight] = useState(null)
  const [editingMeal, setEditingMeal] = useState(null)
  const [editingGoal, setEditingGoal] = useState(null)

  // Data states
  const [weightData, setWeightData] = useState([
    { id: 1, date: "Mar 1", weight: 168 },
    { id: 2, date: "Mar 5", weight: 167 },
    { id: 3, date: "Mar 10", weight: 166.5 },
    { id: 4, date: "Mar 15", weight: 166 },
    { id: 5, date: "Mar 20", weight: 165.5 },
    { id: 6, date: "Mar 25", weight: 165 },
    { id: 7, date: "Mar 30", weight: 164.5 },
  ])

  const [workoutData, setWorkoutData] = useState([
    { id: 1, name: "Upper Body Strength", date: "Mar 25, 2025", duration: "45", calories: 320, completed: true },
    { id: 2, name: "Morning Run", date: "Mar 24, 2025", duration: "30", calories: 280, completed: true },
    { id: 3, name: "Swimming", date: "Mar 22, 2025", duration: "60", calories: 450, completed: true },
    { id: 4, name: "Lower Body Strength", date: "Mar 21, 2025", duration: "50", calories: 380, completed: true },
  ])

  const [mealData, setMealData] = useState([
    { id: 1, name: "Breakfast Oatmeal", date: "Mar 25, 2025", calories: 350, type: "breakfast" },
    { id: 2, name: "Chicken Salad", date: "Mar 25, 2025", calories: 450, type: "lunch" },
    { id: 3, name: "Salmon with Vegetables", date: "Mar 25, 2025", calories: 550, type: "dinner" },
    { id: 4, name: "Protein Shake", date: "Mar 25, 2025", calories: 200, type: "snack" },
  ])

  const [goals, setGoals] = useState([
    { id: 1, name: "Weight Loss", current: 68, target: "155 lbs", targetDate: "June 1, 2025" },
    { id: 2, name: "Daily Steps", current: 85, target: "10,000 steps daily", targetDate: "Ongoing" },
    { id: 3, name: "Workout Frequency", current: 80, target: "5 workouts per week", targetDate: "Ongoing" },
    {
      id: 4,
      name: "Strength Improvement",
      current: 45,
      target: "Increase max lifts by 15%",
      targetDate: "July 15, 2025",
    },
  ])

  const caloriesData = [
    { day: "Mon", calories: 2100, burned: 350 },
    { day: "Tue", calories: 2200, burned: 420 },
    { day: "Wed", calories: 1950, burned: 380 },
    { day: "Thu", calories: 2050, burned: 450 },
    { day: "Fri", calories: 2300, burned: 320 },
    { day: "Sat", calories: 2400, burned: 280 },
    { day: "Sun", calories: 2150, burned: 150 },
  ]

  const nutritionData = [
    { name: "Protein", value: 30 },
    { name: "Carbs", value: 45 },
    { name: "Fat", value: 25 },
  ]

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28"]

  // WORKOUT CRUD OPERATIONS
  // CREATE - Add a new workout
  const handleAddWorkout = (e) => {
    e.preventDefault()
    const newWorkoutItem = {
      id: Date.now(),
      name: newWorkout.name,
      date: newWorkout.date,
      duration: newWorkout.duration,
      calories: Number.parseInt(newWorkout.calories),
      completed: true,
    }
    setWorkoutData([...workoutData, newWorkoutItem])
    setShowAddWorkoutModal(false)
    setNewWorkout({ name: "", duration: "", calories: "", date: "" })
  }

  // UPDATE - Open edit workout modal
  const handleEditWorkout = (workout) => {
    setEditingWorkout(workout)
    setNewWorkout({
      name: workout.name,
      duration: workout.duration,
      calories: workout.calories.toString(),
      date: workout.date,
    })
    setShowEditWorkoutModal(true)
  }

  // UPDATE - Save edited workout
  const handleSaveEditedWorkout = (e) => {
    e.preventDefault()
    const updatedWorkouts = workoutData.map((workout) => {
      if (workout.id === editingWorkout.id) {
        return {
          ...workout,
          name: newWorkout.name,
          duration: newWorkout.duration,
          calories: Number.parseInt(newWorkout.calories),
          date: newWorkout.date,
        }
      }
      return workout
    })
    setWorkoutData(updatedWorkouts)
    setShowEditWorkoutModal(false)
    setEditingWorkout(null)
    setNewWorkout({ name: "", duration: "", calories: "", date: "" })
  }

  // DELETE - Remove a workout
  const handleDeleteWorkout = (id) => {
    if (confirm("Are you sure you want to delete this workout?")) {
      const updatedWorkouts = workoutData.filter((workout) => workout.id !== id)
      setWorkoutData(updatedWorkouts)
    }
  }

  // WEIGHT CRUD OPERATIONS
  // CREATE - Add a new weight entry
  const handleAddWeight = (e) => {
    e.preventDefault()
    const newWeightItem = {
      id: Date.now(),
      date: newWeight.date,
      weight: Number.parseFloat(newWeight.weight),
    }
    setWeightData([...weightData, newWeightItem])
    setShowAddWeightModal(false)
    setNewWeight({ weight: "", date: "" })
  }

  // UPDATE - Open edit weight modal
  const handleEditWeight = (weight) => {
    setEditingWeight(weight)
    setNewWeight({
      weight: weight.weight.toString(),
      date: weight.date,
    })
    setShowEditWeightModal(true)
  }

  // UPDATE - Save edited weight
  const handleSaveEditedWeight = (e) => {
    e.preventDefault()
    const updatedWeights = weightData.map((weight) => {
      if (weight.id === editingWeight.id) {
        return {
          ...weight,
          weight: Number.parseFloat(newWeight.weight),
          date: newWeight.date,
        }
      }
      return weight
    })
    setWeightData(updatedWeights)
    setShowEditWeightModal(false)
    setEditingWeight(null)
    setNewWeight({ weight: "", date: "" })
  }

  // DELETE - Remove a weight entry
  const handleDeleteWeight = (id) => {
    if (confirm("Are you sure you want to delete this weight entry?")) {
      const updatedWeights = weightData.filter((weight) => weight.id !== id)
      setWeightData(updatedWeights)
    }
  }

  // MEAL CRUD OPERATIONS
  // CREATE - Add a new meal
  const handleAddMeal = (e) => {
    e.preventDefault()
    const newMealItem = {
      id: Date.now(),
      name: newMeal.name,
      date: newMeal.date,
      calories: Number.parseInt(newMeal.calories),
      type: newMeal.type,
    }
    setMealData([...mealData, newMealItem])
    setShowAddMealModal(false)
    setNewMeal({ name: "", calories: "", type: "breakfast", date: "" })
  }

  // UPDATE - Open edit meal modal
  const handleEditMeal = (meal) => {
    setEditingMeal(meal)
    setNewMeal({
      name: meal.name,
      calories: meal.calories.toString(),
      type: meal.type,
      date: meal.date,
    })
    setShowEditMealModal(true)
  }

  // UPDATE - Save edited meal
  const handleSaveEditedMeal = (e) => {
    e.preventDefault()
    const updatedMeals = mealData.map((meal) => {
      if (meal.id === editingMeal.id) {
        return {
          ...meal,
          name: newMeal.name,
          calories: Number.parseInt(newMeal.calories),
          type: newMeal.type,
          date: newMeal.date,
        }
      }
      return meal
    })
    setMealData(updatedMeals)
    setShowEditMealModal(false)
    setEditingMeal(null)
    setNewMeal({ name: "", calories: "", type: "breakfast", date: "" })
  }

  // DELETE - Remove a meal
  const handleDeleteMeal = (id) => {
    if (confirm("Are you sure you want to delete this meal?")) {
      const updatedMeals = mealData.filter((meal) => meal.id !== id)
      setMealData(updatedMeals)
    }
  }

  // GOAL CRUD OPERATIONS
  // CREATE - Add a new goal
  const handleAddGoal = (e) => {
    e.preventDefault()
    const newGoalItem = {
      id: Date.now(),
      name: newGoal.name,
      target: newGoal.target,
      current: Number.parseInt(newGoal.current),
      targetDate: newGoal.targetDate,
    }
    setGoals([...goals, newGoalItem])
    setShowAddGoalModal(false)
    setNewGoal({ name: "", target: "", current: "", targetDate: "" })
  }

  // UPDATE - Open edit goal modal
  const handleEditGoal = (goal) => {
    setEditingGoal(goal)
    setNewGoal({
      name: goal.name,
      target: goal.target,
      current: goal.current.toString(),
      targetDate: goal.targetDate,
    })
    setShowEditGoalModal(true)
  }

  // UPDATE - Save edited goal
  const handleSaveEditedGoal = (e) => {
    e.preventDefault()
    const updatedGoals = goals.map((goal) => {
      if (goal.id === editingGoal.id) {
        return {
          ...goal,
          name: newGoal.name,
          target: newGoal.target,
          current: Number.parseInt(newGoal.current),
          targetDate: newGoal.targetDate,
        }
      }
      return goal
    })
    setGoals(updatedGoals)
    setShowEditGoalModal(false)
    setEditingGoal(null)
    setNewGoal({ name: "", target: "", current: "", targetDate: "" })
  }

  // DELETE - Remove a goal
  const handleDeleteGoal = (id) => {
    if (confirm("Are you sure you want to delete this goal?")) {
      const updatedGoals = goals.filter((goal) => goal.id !== id)
      setGoals(updatedGoals)
    }
  }

  // Toggle workout completion status
  const toggleWorkoutCompletion = (id) => {
    const updatedWorkouts = workoutData.map((workout) => {
      if (workout.id === id) {
        return {
          ...workout,
          completed: !workout.completed,
        }
      }
      return workout
    })
    setWorkoutData(updatedWorkouts)
  }

  return (
    <div className="dashboard-container">
      <header className="site-header">
        <div className="logo">
          <Link to="/">
            <h1>FitTrack</h1>
          </Link>
        </div>
        <nav className="main-nav">
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About Us</Link>
            </li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
            <li>
              <Link to="/login" className="login-btn">
                Login/Register
              </Link>
            </li>
            <li>
              <button onClick={() => navigate("/")} className="logout-btn">
                Logout
              </button>
            </li>
          </ul>
        </nav>
      </header>

      <div className="dashboard-title">
        <h2>Your Fitness Dashboard</h2>
        <p>Track your health and fitness journey</p>
      </div>

      <div className="stats-summary">
        <div className="stat-card">
          <h3>Current Weight</h3>
          <p className="stat-value">165 lbs</p>
          <p className="stat-change">
            <span className="down">↓ 2 lbs</span> from last week
          </p>
        </div>
        <div className="stat-card">
          <h3>Active Days</h3>
          <p className="stat-value">5/7</p>
          <p className="stat-change">
            <span className="up">↑ 1 day</span> from last week
          </p>
        </div>
        <div className="stat-card">
          <h3>Calories Burned</h3>
          <p className="stat-value">4,350</p>
          <p className="stat-change">
            <span className="up">↑ 8%</span> from last week
          </p>
        </div>
        <div className="stat-card">
          <h3>Goal Progress</h3>
          <p className="stat-value">68%</p>
          <p className="stat-change">
            <span className="up">↑ 5%</span> from last week
          </p>
        </div>
      </div>

      <div className="dashboard-tabs">
        <div className="tab-buttons">
          <button className={activeTab === "overview" ? "active" : ""} onClick={() => setActiveTab("overview")}>
            Overview
          </button>
          <button className={activeTab === "workouts" ? "active" : ""} onClick={() => setActiveTab("workouts")}>
            Workouts
          </button>
          <button className={activeTab === "nutrition" ? "active" : ""} onClick={() => setActiveTab("nutrition")}>
            Nutrition
          </button>
          <button className={activeTab === "goals" ? "active" : ""} onClick={() => setActiveTab("goals")}>
            Goals
          </button>
        </div>

        <div className="tab-content">
          {activeTab === "overview" && (
            <div className="overview-tab">
              <div className="charts-container">
                <div className="chart-card">
                  <h3>Weight Trend</h3>
                  <div className="chart-wrapper">
                    <ResponsiveContainer width="100%" height={250}>
                      <LineChart data={weightData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis domain={["dataMin - 2", "dataMax + 2"]} />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="weight" stroke="#3b82f6" activeDot={{ r: 8 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="chart-card">
                  <h3>Calories (Consumed vs. Burned)</h3>
                  <div className="chart-wrapper">
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={caloriesData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="day" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="calories" fill="#82ca9d" name="Calories Consumed" />
                        <Bar dataKey="burned" fill="#3b82f6" name="Calories Burned" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <div className="quick-actions">
                <h3>Quick Actions</h3>
                <div className="action-buttons">
                  <button onClick={() => setShowAddWorkoutModal(true)}>Log Workout</button>
                  <button onClick={() => setShowAddWeightModal(true)}>Log Weight</button>
                  <button onClick={() => setShowAddMealModal(true)}>Log Meal</button>
                  <button onClick={() => setShowAddGoalModal(true)}>Add Goal</button>
                </div>
              </div>

              <div className="recent-activities">
                <h3>Recent Workouts</h3>
                <div className="activities-list">
                  {workoutData.slice(0, 3).map((workout, index) => (
                    <div className="activity-item" key={index}>
                      <div className="activity-info">
                        <h4>{workout.name}</h4>
                        <p>
                          {workout.date} • {workout.duration} min • {workout.calories} calories
                        </p>
                      </div>
                      <div className="activity-status">
                        <span
                          className={workout.completed ? "completed" : "pending"}
                          onClick={() => toggleWorkoutCompletion(workout.id)}
                          style={{ cursor: "pointer" }}
                        >
                          {workout.completed ? "Completed" : "Pending"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === "workouts" && (
            <div className="workouts-tab">
              <div className="section-header">
                <h3>Workout History</h3>
                <button onClick={() => setShowAddWorkoutModal(true)}>Add Workout</button>
              </div>

              <div className="workout-list">
                {workoutData.map((workout, index) => (
                  <div className="workout-item" key={index}>
                    <div className="workout-info">
                      <h4>{workout.name}</h4>
                      <p>
                        {workout.date} • {workout.duration} min • {workout.calories} calories
                      </p>
                    </div>
                    <div className="workout-actions">
                      <button
                        className={workout.completed ? "status-btn completed" : "status-btn pending"}
                        onClick={() => toggleWorkoutCompletion(workout.id)}
                      >
                        {workout.completed ? "Completed" : "Pending"}
                      </button>
                      <button className="edit-btn" onClick={() => handleEditWorkout(workout)}>
                        Edit
                      </button>
                      <button className="delete-btn" onClick={() => handleDeleteWorkout(workout.id)}>
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="workout-calendar">
                <h3>Workout Schedule</h3>
                <div className="calendar-placeholder">
                  <p>Calendar view will be displayed here</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === "nutrition" && (
            <div className="nutrition-tab">
              <div className="section-header">
                <h3>Nutrition Overview</h3>
                <button onClick={() => setShowAddMealModal(true)}>Log Meal</button>
              </div>

              <div className="nutrition-charts">
                <div className="chart-card">
                  <h3>Macronutrient Distribution</h3>
                  <div className="chart-wrapper">
                    <ResponsiveContainer width="100%" height={250}>
                      <PieChart>
                        <Pie
                          data={nutritionData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {nutritionData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="chart-card">
                  <h3>Calorie Intake (Last 7 Days)</h3>
                  <div className="chart-wrapper">
                    <ResponsiveContainer width="100%" height={250}>
                      <BarChart data={caloriesData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="day" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="calories" fill="#82ca9d" name="Calories Consumed" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <div className="meal-log">
                <h3>Recent Meals</h3>
                <div className="meal-list">
                  {mealData.map((meal, index) => (
                    <div className="workout-item" key={index}>
                      <div className="workout-info">
                        <h4>{meal.name}</h4>
                        <p>
                          {meal.date} • {meal.type} • {meal.calories} calories
                        </p>
                      </div>
                      <div className="workout-actions">
                        <button className="edit-btn" onClick={() => handleEditMeal(meal)}>
                          Edit
                        </button>
                        <button className="delete-btn" onClick={() => handleDeleteMeal(meal.id)}>
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === "goals" && (
            <div className="goals-tab">
              <div className="section-header">
                <h3>Fitness Goals</h3>
                <button onClick={() => setShowAddGoalModal(true)}>Add New Goal</button>
              </div>

              <div className="goals-list">
                {goals.map((goal, index) => (
                  <div className="goal-item" key={index}>
                    <div className="goal-info">
                      <h4>{goal.name}</h4>
                      <p>
                        Goal: {goal.target} by {goal.targetDate}
                      </p>
                    </div>
                    <div className="goal-progress">
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${goal.current}%` }}></div>
                      </div>
                      <span className="progress-text">{goal.current}%</span>
                    </div>
                    <div className="goal-actions">
                      <button className="edit-btn" onClick={() => handleEditGoal(goal)}>
                        Edit
                      </button>
                      <button className="delete-btn" onClick={() => handleDeleteGoal(goal.id)}>
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add Workout Modal */}
      {showAddWorkoutModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Log Workout</h3>
              <button className="close-btn" onClick={() => setShowAddWorkoutModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleAddWorkout}>
              <div className="form-group">
                <label>Workout Name</label>
                <input
                  type="text"
                  value={newWorkout.name}
                  onChange={(e) => setNewWorkout({ ...newWorkout, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Duration (minutes)</label>
                <input
                  type="number"
                  value={newWorkout.duration}
                  onChange={(e) => setNewWorkout({ ...newWorkout, duration: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Calories Burned</label>
                <input
                  type="number"
                  value={newWorkout.calories}
                  onChange={(e) => setNewWorkout({ ...newWorkout, calories: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={newWorkout.date}
                  onChange={(e) => setNewWorkout({ ...newWorkout, date: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit">Save Workout</button>
                <button type="button" onClick={() => setShowAddWorkoutModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Workout Modal */}
      {showEditWorkoutModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Edit Workout</h3>
              <button className="close-btn" onClick={() => setShowEditWorkoutModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleSaveEditedWorkout}>
              <div className="form-group">
                <label>Workout Name</label>
                <input
                  type="text"
                  value={newWorkout.name}
                  onChange={(e) => setNewWorkout({ ...newWorkout, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Duration (minutes)</label>
                <input
                  type="number"
                  value={newWorkout.duration}
                  onChange={(e) => setNewWorkout({ ...newWorkout, duration: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Calories Burned</label>
                <input
                  type="number"
                  value={newWorkout.calories}
                  onChange={(e) => setNewWorkout({ ...newWorkout, calories: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={newWorkout.date}
                  onChange={(e) => setNewWorkout({ ...newWorkout, date: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit">Update Workout</button>
                <button type="button" onClick={() => setShowEditWorkoutModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Weight Modal */}
      {showAddWeightModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Log Weight</h3>
              <button className="close-btn" onClick={() => setShowAddWeightModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleAddWeight}>
              <div className="form-group">
                <label>Weight (lbs)</label>
                <input
                  type="number"
                  step="0.1"
                  value={newWeight.weight}
                  onChange={(e) => setNewWeight({ ...newWeight, weight: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={newWeight.date}
                  onChange={(e) => setNewWeight({ ...newWeight, date: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit">Save Weight</button>
                <button type="button" onClick={() => setShowAddWeightModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Weight Modal */}
      {showEditWeightModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Edit Weight Entry</h3>
              <button className="close-btn" onClick={() => setShowEditWeightModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleSaveEditedWeight}>
              <div className="form-group">
                <label>Weight (lbs)</label>
                <input
                  type="number"
                  step="0.1"
                  value={newWeight.weight}
                  onChange={(e) => setNewWeight({ ...newWeight, weight: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={newWeight.date}
                  onChange={(e) => setNewWeight({ ...newWeight, date: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit">Update Weight</button>
                <button type="button" onClick={() => setShowEditWeightModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Meal Modal */}
      {showAddMealModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Log Meal</h3>
              <button className="close-btn" onClick={() => setShowAddMealModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleAddMeal}>
              <div className="form-group">
                <label>Meal Name</label>
                <input
                  type="text"
                  value={newMeal.name}
                  onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Calories</label>
                <input
                  type="number"
                  value={newMeal.calories}
                  onChange={(e) => setNewMeal({ ...newMeal, calories: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Meal Type</label>
                <select value={newMeal.type} onChange={(e) => setNewMeal({ ...newMeal, type: e.target.value })}>
                  <option value="breakfast">Breakfast</option>
                  <option value="lunch">Lunch</option>
                  <option value="dinner">Dinner</option>
                  <option value="snack">Snack</option>
                </select>
              </div>
              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={newMeal.date}
                  onChange={(e) => setNewMeal({ ...newMeal, date: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit">Save Meal</button>
                <button type="button" onClick={() => setShowAddMealModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Meal Modal */}
      {showEditMealModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Edit Meal</h3>
              <button className="close-btn" onClick={() => setShowEditMealModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleSaveEditedMeal}>
              <div className="form-group">
                <label>Meal Name</label>
                <input
                  type="text"
                  value={newMeal.name}
                  onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Calories</label>
                <input
                  type="number"
                  value={newMeal.calories}
                  onChange={(e) => setNewMeal({ ...newMeal, calories: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Meal Type</label>
                <select value={newMeal.type} onChange={(e) => setNewMeal({ ...newMeal, type: e.target.value })}>
                  <option value="breakfast">Breakfast</option>
                  <option value="lunch">Lunch</option>
                  <option value="dinner">Dinner</option>
                  <option value="snack">Snack</option>
                </select>
              </div>
              <div className="form-group">
                <label>Date</label>
                <input
                  type="date"
                  value={newMeal.date}
                  onChange={(e) => setNewMeal({ ...newMeal, date: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit">Update Meal</button>
                <button type="button" onClick={() => setShowEditMealModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Goal Modal */}
      {showAddGoalModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Add New Goal</h3>
              <button className="close-btn" onClick={() => setShowAddGoalModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleAddGoal}>
              <div className="form-group">
                <label>Goal Name</label>
                <input
                  type="text"
                  value={newGoal.name}
                  onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Target</label>
                <input
                  type="text"
                  value={newGoal.target}
                  onChange={(e) => setNewGoal({ ...newGoal, target: e.target.value })}
                  required
                  placeholder="e.g., 155 lbs, 10,000 steps daily"
                />
              </div>
              <div className="form-group">
                <label>Current Progress (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={newGoal.current}
                  onChange={(e) => setNewGoal({ ...newGoal, current: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Target Date</label>
                <input
                  type="text"
                  value={newGoal.targetDate}
                  onChange={(e) => setNewGoal({ ...newGoal, targetDate: e.target.value })}
                  required
                  placeholder="e.g., June 1, 2025, Ongoing"
                />
              </div>
              <div className="form-actions">
                <button type="submit">Save Goal</button>
                <button type="button" onClick={() => setShowAddGoalModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Goal Modal */}
      {showEditGoalModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>Edit Goal</h3>
              <button className="close-btn" onClick={() => setShowEditGoalModal(false)}>
                ×
              </button>
            </div>
            <form onSubmit={handleSaveEditedGoal}>
              <div className="form-group">
                <label>Goal Name</label>
                <input
                  type="text"
                  value={newGoal.name}
                  onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Target</label>
                <input
                  type="text"
                  value={newGoal.target}
                  onChange={(e) => setNewGoal({ ...newGoal, target: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Current Progress (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={newGoal.current}
                  onChange={(e) => setNewGoal({ ...newGoal, current: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Target Date</label>
                <input
                  type="text"
                  value={newGoal.targetDate}
                  onChange={(e) => setNewGoal({ ...newGoal, targetDate: e.target.value })}
                  required
                />
              </div>
              <div className="form-actions">
                <button type="submit">Update Goal</button>
                <button type="button" onClick={() => setShowEditGoalModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default Dashboard
